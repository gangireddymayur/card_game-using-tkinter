from tkinter import *
from PIL import Image, ImageTk
from tkinter import ttk
import main

s = 1
count = 1
round_count = 0
lis = []
round_names = []
window = Tk()
window.title("project")
window.geometry("4000x800")
round_1 = main.SnapEngine()
round_2 = main.SnapEngine()
round_3 = main.SnapEngine()
main_obj = round_1
main_obj.divide()
round_names.append([round_2, round_3])
round_names.append(["round_2", "round_3"])
key = 1
b1 = Button()


def how_to_play():
    Label(button_frame, text="HOW TO PLAY", fg="red", background="white", font=("Arial", 15)).place(x=300, y=10)
    Label(button_frame, text="Andar-Bahar Game of chance", fg="brown", background="white",
          font=("Arial", 13)) \
        .place(x=260, y=45)
    Label(button_frame, text="The game usually consists of 2 players holding 26 cards each", fg="black",
          background="white",
          font=("Arial", 13)) \
        .place(x=30, y=73)
    Label(button_frame, text="Each player in turn plays a card to the table, and whenever a card matches with the "
                             "previous card\n of other player, all the cards which is on table is added to the player "
                             "whose card matches with\n the previous card."
                             "The round will continue till\n all the cards of any one player get exhausted"
                             " the player whose cards get exhausted\n is declared as loser and player with cards is "
                             "declared as winner", fg="black", background="white", font=("Arial", 13)).place(x=30, y=95)
    Label(button_frame, text="The _______ __ represents the no of match-cards in the following round.The _________ has "
                             "\neach round information", fg="black",
          background="white",
          font=("Arial", 13)) \
        .place(x=30, y=195)
    Label(button_frame, text="match_table", fg="green", background="white", font=("Arial", 13)).place(x=60, y=195)

    Label(button_frame, text="round table", fg="blue", background="white", font=("Arial", 13)).place(x=590, y=195)

    Button(button_frame, text="PLAY", fg="red", background="white", font=("Arial", 15), command=lambda: [button()]) \
        .place(x=330, y=240)


def round_change():
    if key == 1:
        global round_count, main_obj, s
        main_obj = round_names[0][round_count]
        main_obj.divide()
        round_name_label['text'] = f"{round_names[1][round_count]}"
        round_count = round_count + 1
        s = 1
    else:
        round_name_label['text'] = " "


def end(value):
    global key
    key = 0
    make_invisible(b1)
    destroy_frame(button_frame)
    button_frame['highlightbackground'] = "white"
    button_frame.place(x=475, y=500)
    Label(button_frame, text="GAME OVER", background="white", fg="red", font=("Arial", 15)).pack()
    Label(pile, text=f"{value}\nhas won the game", fg="green", background="white", font=("Arial", 15)).place(x=60,
                                                                                                             y=150)


class create:
    def __init__(self):
        self.img = None
        self.resized_image = None
        self.new_image = None
        self.canvas = None

    def image(self, f, part1, part2):
        self.canvas = Canvas(f, width=280, height=350, highlightbackground="white", background="blue")
        self.canvas.pack()
        k = f"{part1}" + f"{part2}" + ".png"
        self.img = (Image.open(f"{k}"))
        self.resized_image = self.img.resize((280, 350))
        self.new_image = ImageTk.PhotoImage(self.resized_image)
        self.canvas.create_image(2, 2, anchor=NW, image=self.new_image)

    def change_red(self):
        self.canvas['background'] = "red"

    def change_blue(self):
        self.canvas['background'] = "blue"

    def change_green(self):
        self.canvas['background'] = "green"


def reset_all():
    destroy_frame(game_table)
    states_info_table()
    destroy_frame(pile)
    destroy_frame(button_frame)
    main_table()
    round_change()
    button()


def button():
    destroy_frame(button_frame)
    button_frame.place(x=400, y=500)
    if key == 1:
        global b1
        b1 = Button(button_frame, text="start", font=("Arial", 10), width=30, height=5, command=lambda: [start(b1)])
        b1.pack()


def main_table():
    if main_obj == round_1:
        my_game3.insert(parent='', index='end', iid=str(1), text='',
                        values=('round - 1', f'{round_1.player1.status}',
                                f'{round_1.player2.status}'))
    if main_obj == round_2:
        my_game3.insert(parent='', index='end', iid=str(2), text='',
                        values=('round - 2', f'{round_2.player1.status}',
                                f'{round_2.player2.status}'))
    if main_obj == round_3:
        my_game3.insert(parent='', index='end', iid=str(3), text='',
                        values=('round - 3', f'{round_3.player1.status}',
                                f'{round_3.player2.status}'))
    if lis.count('player1') > lis.count('player2') and main_obj != round_1:
        end("player-1")
        Label(main_frame, text="player - 1 has won\nthe game", bg="white").place(x=100, y=100)
    elif main_obj != round_1 and lis.count('player1') != lis.count('player2'):
        end("player-2")
        Label(main_frame, text="player - 2 has won\nthe game", bg="white").place(x=100, y=100)


def states_info_table():
    global my_game
    my_game = ttk.Treeview(game_table, selectmode='browse')
    bar = ttk.Scrollbar(game_table, orient="vertical", command=my_game.yview)
    bar.pack(side='right', fill='x')
    my_game.configure(xscrollcommand=bar.set)
    my_game['columns'] = ('s_no', 'match', 'player_1', 'player_2', 'WON')
    my_game.column("#0", width=0, stretch=NO)
    my_game.column("s_no", anchor=CENTER, width=80)
    my_game.column("match", anchor=CENTER, width=80)
    my_game.column("player_1", anchor=CENTER, width=90)
    my_game.column("player_2", anchor=CENTER, width=90)
    my_game.column("WON", anchor=CENTER, width=80)
    my_game.heading("#0", text="", anchor=CENTER)
    my_game.heading("s_no", text="s_no", anchor=CENTER)
    my_game.heading("match", text="match", anchor=CENTER)
    my_game.heading("player_1", text="P1_no of cards", anchor=CENTER)
    my_game.heading("player_2", text="P2_no of cards", anchor=CENTER)
    my_game.heading("WON", text="WON", anchor=CENTER)
    my_game.pack()


def winner_info_table():
    button_frame.place(x=380, y=500)
    my_game2 = ttk.Treeview(button_frame)
    my_game2['columns'] = ('s_no', 'match', 'status')
    my_game2.column("#0", width=0, stretch=NO)
    my_game2.column("s_no", anchor=CENTER, width=100)
    my_game2.column("match", anchor=CENTER, width=100)
    my_game2.column("status", anchor=CENTER, width=100)
    my_game2.heading("#0", text="", anchor=CENTER)
    my_game2.heading("s_no", text="player", anchor=CENTER)
    my_game2.heading("match", text="no of cards", anchor=CENTER)
    my_game2.heading("status", text="status", anchor=CENTER)
    my_game2.pack()
    my_game2.insert(parent='', index='end', iid=str(1), text='',
                    values=('player-1', f'{main_obj.player1.player_len()}',
                            f'{main_obj.player1.status}'))
    my_game2.insert(parent='', index='end', iid=str(2), text='',
                    values=('player-2', f'{main_obj.player2.player_len()}',
                            f'{main_obj.player2.status}'))
    l11 = Label(button_frame, text=f"{main_obj.status} has won the round", font=1, background="white")
    l11.place(x=35, y=100)
    lis.append(main_obj.status)
    reset = Button(button_frame, text="next round", width=10, height=2, command=lambda: [reset_all()])
    reset.place(x=110, y=130)


def make_invisible(widget):
    widget.pack_forget()
    winner_info_table()


def destroy_frame(frame):
    for widgets in frame.winfo_children():
        widgets.destroy()


def colour():
    if main_obj.current_player.name == "player1":
        l1['fg'] = "red"
        l3['fg'] = "black"
        obj.change_blue()
        obj1.change_red()
    else:
        l3['fg'] = "red"
        l1['fg'] = "black"
        obj1.change_blue()
        obj.change_red()


def start(b):
    global s, count, b1
    if s == 0:
        if main_obj.play() == "won":
            my_game.insert(parent='', index='end', iid=str(count), text='',
                           values=(f'{count}', f'{main_obj.current_player.current_card.suit.value}'
                                               f'{main_obj.current_player.current_card.value} - '
                                               f'{main_obj.Pile.pr_card.suit.value}'
                                               f'{main_obj.Pile.pr_card.value}',
                                   f'{main_obj.player1.player_len()}',
                                   f'{main_obj.player2.player_len()}',
                                   f'{main_obj.current_player.name}'))
            count = count + 1
        if main_obj.end() == "F":
            make_invisible(b)
        destroy_frame(pile)
        obj3.image(pile, str(main_obj.current_player.current_card.value),
                   main_obj.current_player.current_card.suit.value)
        obj3.change_green()
        main_obj.current()
    else:
        main_obj.current()
        s = 0
    player1_length['text'] = f"{main_obj.player1.player_len()}"
    player2_length['text'] = f"{main_obj.Pile.lent()}"
    player3_length['text'] = f"{main_obj.player2.player_len()}"
    colour()
    b1['text'] = f"{main_obj.current_player.name}\nflip the\ncard"
    b1['fg'] = "red"


# frames
frame1 = Frame(window, highlightbackground="black", background="white", highlightthickness=1, width=1530,
               height=780)
frame1.place(x=3, y=5)
player1 = Frame(frame1, highlightbackground="black", background="white", highlightthickness=1, width=280,
                height=350)
player1.place(x=50, y=50)
pile = Frame(frame1, highlightbackground="black", background="white", highlightthickness=1, width=280, height=350)
pile.place(x=390, y=50)
player2 = Frame(frame1, highlightbackground="black", background="white", highlightthickness=1, width=280,
                height=350)
player2.place(x=730, y=50)
game_table = Frame(frame1, highlightbackground="black", background="white", highlightthickness=1, width=450,
                   height=350)
game_table.place(x=1050, y=100)
button_frame = Frame(frame1, highlightbackground="black", background="white", highlightthickness=1, width=750,
                     height=290)
button_frame.place(x=140, y=460)
states_info_table()
# labels
round_name_label = Label(frame1, text="round - 1", background="white", fg="red", font=("Arial", 15))
round_name_label.place(x=1230, y=15)
player1_length = Label(frame1, text=f"{main_obj.player1.player_len()}", font=5, background="white")
player1_length.place(x=160, y=430)
player2_length = Label(frame1, text=f"{main_obj.deck.length()}", font=5, background="white")
player2_length.place(x=520, y=430)
player3_length = Label(frame1, text=f"{main_obj.player2.player_len()}", font=5, background="white")
player3_length.place(x=850, y=430)
l1 = Label(frame1, text="player-1", background="white", fg="black", font=("Arial", 15))
l1.place(x=160, y=15)
l2 = Label(frame1, text="pile", background="white", fg="black", font=("Arial", 15))
l2.place(x=510, y=15)
l3 = Label(frame1, text="player-2", background="white", fg="black", font=("Arial", 15))
l3.place(x=840, y=15)
Label(frame1, text="rounds_table", background="white", fg="blue", font=("Arial", 15)).place(x=1140, y=365)
Label(frame1, text="match_table", background="white", fg="green", font=("Arial", 15)).place(x=1220, y=65)
main_frame = Frame(frame1, highlightbackground="black", background="white", highlightthickness=1, width=400, height=350)
main_frame.place(x=1050, y=400)
# table
my_game3 = ttk.Treeview(main_frame)
my_game3['columns'] = ('s_no', 'match', 'status')
my_game3.column("#0", width=0, stretch=NO)
my_game3.column("s_no", anchor=CENTER, width=100)
my_game3.column("match", anchor=CENTER, width=100)
my_game3.column("status", anchor=CENTER, width=100)
my_game3.heading("#0", text="", anchor=CENTER)
my_game3.heading("s_no", text="rounds", anchor=CENTER)
my_game3.heading("match", text="player-1", anchor=CENTER)
my_game3.heading("status", text="player-2", anchor=CENTER)
my_game3.pack()
# object creation
obj = create()
obj.image(player2, "green", "_back")
obj1 = create()
obj1.image(player1, "green", "_back")
obj3 = create()
# how to play
how_to_play()
window.mainloop()
