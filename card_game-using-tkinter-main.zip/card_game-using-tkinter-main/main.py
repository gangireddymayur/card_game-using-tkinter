from enum import Enum
import random


class Suits(Enum):
    CLUB = "C"
    SPADE = "S"
    HEART = "H"
    DIAMOND = "D"


class Card:
    suit = None
    value = None

    def __init__(self, suit, value):
        self.suit = suit
        self.value = value


class Deck:
    cards = None

    def __init__(self):
        self.cards = []

        for suit in Suits:
            for value in range(2, 11):
                self.cards.append(Card(suit, value))
            for value in ["A", "J", "K", "Q"]:
                self.cards.append(Card(suit, value))

    def shuffle(self):
        random.shuffle(self.cards)

    def deal(self):
        return self.cards.pop()

    def length(self):
        return len(self.cards)


class pile:
    cards = None

    def __init__(self):
        self.cards = []
        self.pr_card = None

    def add(self, card):
        self.cards.append(card)

    def compare(self):
        if int(self.lent()) == 1 or int(self.lent()) == 0:
            return "not same"
        else:
            if self.cards[-1].value == self.cards[-2].value:
                return "same"
            else:
                return "not same"

    def clear(self):
        self.pr_card = self.cards[-2]
        self.cards.clear()

    def lent(self):
        return len(self.cards)


class player:
    cards = None

    def __init__(self, name):
        self.name = name
        self.cards = []
        self.current_card = None
        self.status = "lost"

    def player_add(self, deck):
        self.cards.append(deck.deal())

    def player_pop(self):
        self.current_card = self.cards[0]
        return self.cards.pop(0)

    def player_all(self, add):
        self.cards = self.cards + add.cards

    def player_len(self):
        return len(self.cards)

    def player_shuffle(self):
        random.shuffle(self.cards)


class SnapEngine:
    player1 = None
    player2 = None
    Pile = None
    deck = None
    current_player = None

    def __init__(self):
        self.player1 = player("player1")
        self.player2 = player("player2")
        self.Pile = pile()
        self.deck = Deck()
        self.current_player = None
        self.status = "Draw"

    def divide(self):
        self.deck.shuffle()
        half = self.deck.length() / 2
        for _ in range(0, int(half)):
            self.player1.player_add(self.deck)
            self.player2.player_add(self.deck)

    def current(self):
        if self.current_player == self.player1:
            self.current_player = self.player2
        else:
            self.current_player = self.player1

    def win_round(self):
        self.current_player.player_shuffle()
        self.current_player.player_all(self.Pile)
        self.Pile.clear()

    def play(self):
        self.Pile.add(self.current_player.player_pop())
        if self.Pile.compare() == "not same":
            return "not same"
        else:
            self.win_round()
            return "won"

    def end(self):
        if self.Pile.lent() == 52:
            return "L"
        elif len(self.current_player.cards) == 0:
            self.current()
            self.current_player.status = "won"
            self.status = self.current_player.name
            return "F"
        else:
            return "T"
